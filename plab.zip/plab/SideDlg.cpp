// SideDlg.cpp : implementation file
//

#include "stdafx.h"
#include "plab.h"
#include "SideDlg.h"
#include ".\sidedlg.h"


// CSideDlg dialog

IMPLEMENT_DYNAMIC(CSideDlg, CDialog)
CSideDlg::CSideDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSideDlg::IDD, pParent)
{
}

CSideDlg::~CSideDlg()
{
}

void CSideDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSideDlg, CDialog)
	ON_EN_CHANGE(IDC_INPUT_AMOUNT, OnEnChangeInputAmount)
END_MESSAGE_MAP()


// CSideDlg message handlers

void CSideDlg::OnEnChangeInputAmount()
{
	Beep(200, 200);
}
