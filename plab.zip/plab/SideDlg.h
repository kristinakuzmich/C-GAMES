#pragma once


// CSideDlg dialog

class CSideDlg : public CDialog
{
	DECLARE_DYNAMIC(CSideDlg)

public:
	CSideDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CSideDlg();

// Dialog Data
	enum { IDD = IDD_MYCTRLBAR };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeInputAmount();
};
