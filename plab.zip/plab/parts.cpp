
#include "stdafx.h"
#include "parts.h"

#define IC_TITLE "�����"

const CRect rcBusRect(15, 15, 530, 485);

#define DECLAREPOS(T) \
	T##(105, 100), T##(265, 100), T##(427, 100), \
	T##(105, 255), T##(265, 255), T##(427, 255), \
	T##(105, 410), T##(265, 410), T##(427, 410)

CPoint ptvICPos[] = {DECLAREPOS(CPoint)};
CRect rcvICPos[] = {DECLAREPOS(FRAMERC)};

long CPartBase::m_nNextID = 0;
long CPartBase::m_nNextOut = 1;

CBrush CAbstractPart::m_RedBrush(RGB(255,0,0));


long CConnector::m_NextConnector = 1;
CPen CConnector::m_ThinPen(PS_SOLID, 1, CONNECTOR_COLOR);
CPen CConnector::m_ThicPen(PS_SOLID, 2, SELECTED_CONNECTOR_COLOR);

CPen CBus::m_Pen(PS_SOLID, 3, RGB(0, 0, 0));

IMPLEMENT_SERIAL(PIN, CObject, 1);
IMPLEMENT_SERIAL(CPartBase, CObject, 1);
IMPLEMENT_SERIAL(CConnector, CPartBase, 1);
IMPLEMENT_SERIAL(CAbstractPart, CPartBase, 1);
IMPLEMENT_SERIAL(CIC, CAbstractPart, 1);
IMPLEMENT_SERIAL(CBus, CAbstractPart, 1);

//////////////////////////////////////////////////////////////////////////////

PIN::PIN(const PIN &src) {
	*this = src;
}

PIN &PIN::operator=(const PIN &src) {
	nID = src.nID;
	yPos = src.yPos;
	bSelected = src.bSelected;
	bConnected = src.bConnected;
	return *this;
}

void PIN::Serialize(CArchive& ar) {
	CObject::Serialize(ar);

	if (ar.IsStoring())
	{
		ar << nID;
		ar << yPos;
		ar << bSelected;
		ar << bConnected;
	}
	else
	{
		ar >> nID;
		ar >> yPos;
		ar >> bSelected;
		ar >> bConnected;
	}
}

//////////////////////////////////////////////////////////////////////////////

void CPartBase::Serialize(CArchive& ar) {
	CObject::Serialize(ar);

	if (ar.IsStoring())
	{
		ar << m_nID;
	}
	else
	{
		ar >> m_nID;
	}
}

//////////////////////////////////////////////////////////////////////////////

CConnector &CConnector::operator=(const CConnector &src) {
	
	/*if (!src.m_nOutPartID)
		m_nID = src.m_nOutID;

	if (!src.m_nInPartID)
		m_nID = src.m_nInID;*/

	m_nOutPartID = src.m_nOutPartID;
	m_nOutPartIndex = src.m_nOutPartIndex;
	m_nOutID = src.m_nOutID;
	m_ptOutPos = src.m_ptOutPos;
	m_nInPartID = src.m_nInPartID;
	m_nInPartIndex = src.m_nInPartIndex;
	m_nInID = src.m_nInID;
	m_ptInPos = src.m_ptInPos;
	m_bSelected = src.m_bSelected;
	m_xInSegment = src.m_xInSegment;
	m_xOutSegment = src.m_xOutSegment;

	return *this;
}

bool CConnector::Validate() {
	/*if (!m_nOutPartID || !m_nInPartID)
		m_nNextOut--;*/
	if (!m_nOutPartID && !m_nInPartID)
		return false;

	return true;
}

bool CConnector::CheckBranch(long xLeft, long xRight, long yCenter, CPoint pt) {
	return (pt.x >= xLeft) && (pt.x <= xRight) && (pt.y >= yCenter - LOOKUP_RADIUS) && (pt.y <= yCenter + LOOKUP_RADIUS);
}

long CConnector::Peekable(CPoint pt) {
	bool b1, b2;
	if ((b1 = CheckBranch(m_ptOutPos.x, m_xOutSegment, m_ptOutPos.y, pt)) ||
		(b2 = CheckBranch(m_xInSegment, m_ptInPos.x, m_ptInPos.y, pt)))
		return m_nID;

	return -1;
}

void CConnector::DisconnectIn(partvect &vect) {
	for (size_t i = 0; i < vect.size(); ++i)
		if (vect[i] != NULL && vect[i]->ID() == m_nInPartID) {
			vect[i]->FreeIn(m_nInID);
			break;
		}
}

void CConnector::DisconnectOut(partvect &vect) {
	for (size_t i = 0; i < vect.size(); ++i)
		if (vect[i] != NULL && vect[i]->ID() == m_nOutPartID) {
			vect[i]->FreeOut(m_nOutID);
			break;
		}
}

void CConnector::Reconnect(partvect &vect, CBus &bus) {
	for (size_t i = 0; i < vect.size(); ++i) {
		if (vect[i] != NULL && vect[i]->ID() == m_nOutPartID) {
			m_ptOutPos = vect[i]->GetOutPt(m_nOutID);
		}
		if (vect[i] != NULL && vect[i]->ID() == m_nInPartID) {
			m_ptInPos = vect[i]->GetInPt(m_nInID);
		}
	}
	bus.ConnectToBus(*this);
}

CPoint CConnector::GetInCell(long dx, long dy, long cell_side) {
	return CPoint(
		(m_ptInPos.x - dx) / cell_side,
		(m_ptInPos.y - dy) / cell_side
	);
}

CPoint CConnector::GetOutCell(long dx, long dy, long cell_side) {
	return CPoint(
		(m_ptOutPos.x - dx) / cell_side,
		(m_ptOutPos.y - dy) / cell_side
	);
}

void CConnector::Render(CDC *pDC) {
	CPen *old_pen;
	COLORREF old_color = pDC->GetTextColor();

	if (m_bSelected) {
		old_pen = pDC->SelectObject(&m_ThicPen);
		pDC->SetTextColor(SELECTED_CONNECTOR_COLOR);
	}
	else {
		old_pen = pDC->SelectObject(&m_ThinPen);
		pDC->SetTextColor(CONNECTOR_COLOR);
	}
	
	char buff[50];
		

	if (m_nOutPartID > 0) {
		strcpy(buff, "(");
		itoa(m_nID, buff + 1, 10);
		strcat(buff, ")");
		itoa(m_nInID, buff + strlen(buff), 10);

		CSize extent = pDC->GetTextExtent(buff);
		pDC->TextOut(m_xOutSegment - 2 - extent.cx, m_ptOutPos.y - PIN_SPACE, buff);

		pDC->MoveTo(m_ptOutPos);
		pDC->LineTo(m_xOutSegment, m_ptOutPos.y);
	}

	if (m_nInPartID > 0) {
		itoa(m_nOutID, buff, 10);
		strcat(buff, "(");
		itoa(m_nID, buff + strlen(buff), 10);
		strcat(buff, ")");

		pDC->TextOut(m_xInSegment + 2, m_ptInPos.y - PIN_SPACE, buff);
		
		pDC->MoveTo(m_xInSegment, m_ptInPos.y);
		pDC->LineTo(m_ptInPos);
	}

	pDC->SetTextColor(old_color);
	pDC->SelectObject(old_pen);
}

void CConnector::Serialize(CArchive& ar) {
	CPartBase::Serialize(ar);

	if (ar.IsStoring())
	{
		ar << m_nOutPartID;
		ar << m_nOutPartIndex;
		ar << m_nOutID;
		ar << m_ptOutPos;
		ar << m_nInPartID;
		ar << m_nInPartIndex;
		ar << m_nInID;
		ar << m_ptInPos;
		ar << m_bSelected;
		ar << m_xInSegment;
		ar << m_xOutSegment;
	}
	else
	{
		ar >> m_nOutPartID;
		ar >> m_nOutPartIndex;
		ar >> m_nOutID;
		ar >> m_ptOutPos;
		ar >> m_nInPartID;
		ar >> m_nInPartIndex;
		ar >> m_nInID;
		ar >> m_ptInPos;
		ar >> m_bSelected;
		ar >> m_xInSegment;
		ar >> m_xOutSegment;
	}
}


//////////////////////////////////////////////////////////////////////////////
CAbstractPart::CAbstractPart(long nIn, long nOut): m_nIn(nIn), m_nOut(nOut) {

	m_vInput.resize(nIn);
	m_vOutput.resize(nOut);

	for (size_t i = 0; i < m_vInput.size(); ++i)
		m_vInput[i].nID = m_nNextOut++;

	for (size_t i = 0; i < m_vOutput.size(); ++i)
		m_vOutput[i].nID = m_nNextOut++;
}

long CAbstractPart::LookupIn(CPoint pt) {
	for (size_t i = 0; i < m_vInput.size(); ++i) {
		if ((pt.x >= m_rcBoundRect.left - LOOKUP_RADIUS && pt.x <= m_rcBoundRect.left + LOOKUP_RADIUS) &&
			(pt.y >= m_vInput[i].yPos - LOOKUP_RADIUS && pt.y <= m_vInput[i].yPos + LOOKUP_RADIUS) &&
			!m_vInput[i].bConnected) {
				m_vInput[i].bSelected = true;
				return (long)i;
		}
		else
			m_vInput[i].bSelected = false;
	}
	return -1;
}

long CAbstractPart::LookupOut(CPoint pt) { 
	for (size_t i = 0; i < m_vOutput.size(); ++i) {
		if ((pt.x >= m_rcBoundRect.right - LOOKUP_RADIUS && pt.x <= m_rcBoundRect.right + LOOKUP_RADIUS) &&
			(pt.y >= m_vOutput[i].yPos - LOOKUP_RADIUS && pt.y <= m_vOutput[i].yPos + LOOKUP_RADIUS) &&
			!m_vOutput[i].bConnected) {
				m_vOutput[i].bSelected = true;
				return (long)i;
		}
		else
			m_vOutput[i].bSelected = false;
	}
	return -1;
}

void CAbstractPart::PlacePins(long yBase, pinvect &vPins) {
	vPins[0].yPos = yBase + PIN_SPACE + 1;

	for (size_t i = 1; i < vPins.size(); ++i)
		vPins[i].yPos = vPins[i - 1].yPos + PIN_SPACE + 1;
}

void CAbstractPart::ConnectIn(CConnector &con, long index) {
	for (size_t i = 0; i < m_vInput.size(); ++i) {
		if (m_vInput[i].bSelected) {
			m_vInput[i].bConnected = true;
			con.m_nInID = m_vInput[i].nID;
			con.m_nInPartID = m_nID;
			con.m_nInPartIndex = index;
			con.m_ptInPos.x = m_rcBoundRect.left;
			con.m_ptInPos.y = m_vInput[i].yPos;
			break;
		}
	}
}

void CAbstractPart::ConnectOut(CConnector &con, long index) {
	for (size_t i = 0; i < m_vOutput.size(); ++i) {
		if (m_vOutput[i].bSelected) {
			m_vOutput[i].bConnected = true;
			con.m_nOutID = m_vOutput[i].nID;
			con.m_nOutPartID = m_nID;
			con.m_nOutPartIndex = index;
			con.m_ptOutPos.x = m_rcBoundRect.right;
			con.m_ptOutPos.y = m_vOutput[i].yPos;
			break;
		}
	}
}

void CAbstractPart::FreeIn(long id) {
	for (size_t i = 0; i < m_vInput.size(); ++i) {
		if (m_vInput[i].nID == id) {
			m_vInput[i].bConnected = false;
			break;
		}
	}
}

void CAbstractPart::FreeOut(long id) {
	for (size_t i = 0; i < m_vOutput.size(); ++i) {
		if (m_vOutput[i].nID == id) {
			m_vOutput[i].bConnected = false;
			break;
		}
	}
}

CPoint CAbstractPart::GetInPt(int id) {
	for (size_t i = 0; i < m_vInput.size(); ++i) {
		if (m_vInput[i].nID == id) {
			return CPoint(m_rcBoundRect.left, m_vInput[i].yPos);
		}
	}
}

CPoint CAbstractPart::GetOutPt(int id) {
	for (size_t i = 0; i < m_vOutput.size(); ++i) {
		if (m_vOutput[i].nID == id) {
			return CPoint(m_rcBoundRect.right, m_vOutput[i].yPos);
		}
	}
}

void CAbstractPart::ClearSel() {
	for (size_t i = 0; i < m_vInput.size(); ++i)
		m_vInput[i].bSelected = false;

	for (size_t i = 0; i < m_vOutput.size(); ++i)
		m_vOutput[i].bSelected = false;
}

void CAbstractPart::Serialize(CArchive& ar) {
	CPartBase::Serialize(ar);

	if (ar.IsStoring())
	{
		ar << m_nIn << m_nOut;
		for (int i = 0; i < m_nIn; ++i)
			m_vInput[i].Serialize(ar);

		for (int i = 0; i < m_nOut; ++i)
			m_vOutput[i].Serialize(ar);

		ar << m_rcBoundRect;
	}
	else
	{
		ar >> m_nIn >> m_nOut;

		m_vInput.resize(m_nIn);
		m_vOutput.resize(m_nOut);

		for (int i = 0; i < m_nIn; ++i)
			m_vInput[i].Serialize(ar);

		for (int i = 0; i < m_nOut; ++i)
			m_vOutput[i].Serialize(ar);
	
		ar >> m_rcBoundRect;
	}
}

//////////////////////////////////////////////////////////////////////////////
CIC::CIC(long nIn, long nOut, CPoint ptCenter): CAbstractPart(nIn, nOut) {

	m_clColor = 0xFF0000;
	SetPos(ptCenter);

}

void CIC::SetPos(CPoint ptCenter) {
	
	#define HALFPAD(height, pins) ( ( height - (PIN_SPACE * (pins + 1) + pins) ) / 2 )

	m_ptCenter = ptCenter;
	
	long max_pin = (m_nIn > m_nOut)? m_nIn: m_nOut;
	long part_height = (PIN_SPACE * (max_pin + 1) + max_pin);
	long part_width = (BODY_WIDTH + PIN_SIZE * 2);

	m_rcBodyRect.top = m_rcBoundRect.top = ptCenter.y - part_height / 2;
	m_rcBodyRect.bottom = m_rcBoundRect.bottom = ptCenter.y + part_height / 2;
	
	m_rcBodyRect.left = ptCenter.x - BODY_WIDTH / 2;
	m_rcBodyRect.right = ptCenter.x + BODY_WIDTH / 2;

	m_rcBoundRect.left = ptCenter.x - part_width / 2;
	m_rcBoundRect.right = ptCenter.x + part_width / 2;

	if (m_nOut) {
		long base = (max_pin == m_nIn)? m_rcBodyRect.top: HALFPAD(part_height, m_nIn) + m_rcBodyRect.top;
		PlacePins(base, m_vInput);
	}

	if (m_nIn) {
		long base = (max_pin == m_nOut)? m_rcBodyRect.top: HALFPAD(part_height, m_nOut) + m_rcBodyRect.top;
		PlacePins(base, m_vOutput);
	}
}

void CIC::Render(CDC *pDC) {
	char buff[50];

	long body_width = m_rcBodyRect.right - m_rcBodyRect.left;
	CSize extent = pDC->GetTextExtent(IC_TITLE);
	COLORREF old_color = pDC->SetTextColor(m_clColor);
	pDC->TextOut(m_rcBodyRect.left + (body_width - extent.cx) / 2, m_rcBodyRect.top + 2, IC_TITLE);

	itoa(m_nID, buff, 10);
	extent = pDC->GetTextExtent(buff);
	pDC->TextOut(m_rcBodyRect.left + (body_width - extent.cx) / 2, m_rcBodyRect.top + extent.cy, buff);
	pDC->SetTextColor(old_color);

	for (size_t i = 0; i < m_vOutput.size(); ++i) {
		pDC->MoveTo(m_rcBodyRect.right, m_vOutput[i].yPos);
		pDC->LineTo(m_rcBoundRect.right, m_vOutput[i].yPos);

		if (m_vOutput[i].nID) {
			pDC->TextOut(m_rcBodyRect.right + 2, m_vOutput[i].yPos - PIN_SPACE, itoa(m_vOutput[i].nID, buff, 10));
		}
	}

	for (size_t i = 0; i < m_vInput.size(); ++i) {
		pDC->MoveTo(m_rcBoundRect.left, m_vInput[i].yPos);
		pDC->LineTo(m_rcBodyRect.left, m_vInput[i].yPos);

		if (m_vInput[i].nID) {
			itoa(m_vInput[i].nID, buff, 10);
			CSize extent = pDC->GetTextExtent(buff);
			pDC->TextOut(m_rcBodyRect.left - 2 - extent.cx, m_vInput[i].yPos - PIN_SPACE, buff);
		}
	}

	for (size_t i = 0; i < m_vOutput.size(); ++i) {
		if (m_vOutput[i].bSelected)
			pDC->FillRect(CRect(m_rcBoundRect.right, m_vOutput[i].yPos - 3, m_rcBoundRect.right + 7, m_vOutput[i].yPos + 4), &m_RedBrush);
	}

	for (size_t i = 0; i < m_vInput.size(); ++i) {
		if (m_vInput[i].bSelected)
			pDC->FillRect(CRect(m_rcBoundRect.left - 7, m_vInput[i].yPos - 3, m_rcBoundRect.left, m_vInput[i].yPos + 4), &m_RedBrush);
	}

	CGdiObject *old_brush = pDC->SelectStockObject(NULL_BRUSH);
	pDC->Rectangle(&m_rcBodyRect);
	pDC->SelectObject((CBrush *)old_brush);

}

void CIC::Serialize(CArchive& ar) {

	CAbstractPart::Serialize(ar);

	if (ar.IsStoring())
	{
		ar << m_ptCenter;
		ar << m_rcBodyRect;
	}
	else
	{
		ar >> m_ptCenter;
		ar >> m_rcBodyRect;
		SetPos(m_ptCenter);
	}
}


//////////////////////////////////////////////////////////////////////////////
CBus::CBus(long nIn, long nOut, CRect rcBounds): CAbstractPart(nIn, nOut) {
	
	m_rcBoundRect = rcBounds;

	for (size_t i = 0; i < m_vOutput.size(); ++i)
		m_vOutput[i].nID = long(i + 1);

	for (size_t j = 0; j < m_vInput.size(); ++j)
		m_vInput[j].nID = long(++i);

	if (m_nOut) {
		long base = (m_rcBoundRect.Height() - (m_nOut * PIN_SPACE + m_nOut)) / 2;
		PlacePins(base, m_vOutput);
	}

	if (m_nIn) {
		long base = (m_rcBoundRect.Height() - (m_nIn * PIN_SPACE + m_nIn)) / 2;
		PlacePins(base, m_vInput);
	}
}

void CBus::AddSegment(long xOffset) {

	m_vSegments.push_back(xOffset);
}

long CBus::LookupIn(CPoint pt) {
	size_t size = m_vSegments.size();
	for (size_t i = 0; i < m_vInput.size(); ++i) {
		if ((pt.x >= m_rcBoundRect.left + m_vSegments[size - 1] - LOOKUP_RADIUS && pt.x <= m_rcBoundRect.left + m_vSegments[size - 1] + LOOKUP_RADIUS) &&
			(pt.y >= m_vInput[i].yPos - LOOKUP_RADIUS && pt.y <= m_vInput[i].yPos + LOOKUP_RADIUS)&&
			!m_vInput[i].bConnected) {
				m_vInput[i].bSelected = true;
				return (long)i;
		}
		else
			m_vInput[i].bSelected = false;
	}
	return -1;
}

long CBus::LookupOut(CPoint pt) { 
	for (size_t i = 0; i < m_vOutput.size(); ++i) {
		if ((pt.x >= m_rcBoundRect.left + m_vSegments[0] - LOOKUP_RADIUS && pt.x <= m_rcBoundRect.left + m_vSegments[0] + LOOKUP_RADIUS) &&
			(pt.y >= m_vOutput[i].yPos - LOOKUP_RADIUS && pt.y <= m_vOutput[i].yPos + LOOKUP_RADIUS) &&
			!m_vOutput[i].bConnected) {
				m_vOutput[i].bSelected = true;
				return (long)i;
		}
		else
			m_vOutput[i].bSelected = false;
	}
	return -1;
}

long CBus::GetGreaterSegment(long xPos) {
	
	for (longvect::iterator i = m_vSegments.begin(); i != m_vSegments.end(); ++i) {
		if (*i > xPos) 
			return m_rcBoundRect.left + *i - 1;
	}

	return -1;
}

long CBus::GetLesserSegment(long xPos) {

	longvect::iterator i = m_vSegments.end();
	do {
		if (*--i < xPos)
			return m_rcBoundRect.left + *i + 2;
	} while(i != m_vSegments.begin());

	return -1;
}

void CBus::ConnectToBus(CConnector &con) {
	con.m_xInSegment = GetLesserSegment(con.m_ptInPos.x);
	con.m_xOutSegment = GetGreaterSegment(con.m_ptOutPos.x);
}

void CBus::Render(CDC *pDC) {
	CPen *old_pen = pDC->SelectObject(&m_Pen);

	for (size_t i = 0; i < m_vSegments.size(); ++i) {
		pDC->MoveTo(m_rcBoundRect.left + m_vSegments[i], m_rcBoundRect.top);
		pDC->LineTo(m_rcBoundRect.left + m_vSegments[i], m_rcBoundRect.bottom);
	}

	pDC->MoveTo(m_rcBoundRect.left + m_vSegments[0], m_rcBoundRect.top);
	pDC->LineTo(m_rcBoundRect.left + m_vSegments[i - 1], m_rcBoundRect.top);
	pDC->SelectObject(old_pen);

	char buff[20];

	for (size_t i = 0; i < m_vOutput.size(); ++i) {
		pDC->MoveTo(m_rcBoundRect.left - 2, m_vOutput[i].yPos);
		pDC->LineTo(m_rcBoundRect.left + m_vSegments[0] - 1, m_vOutput[i].yPos);

		if (m_vOutput[i].nID) {
			itoa(m_vOutput[i].nID, buff, 10);
			CSize extent = pDC->GetTextExtent(buff);
			pDC->TextOut(m_rcBoundRect.left + m_vSegments[0] - 3 - extent.cx, m_vOutput[i].yPos - PIN_SPACE, buff);
		}
	}

	for (size_t i = 0; i < m_vInput.size(); ++i) {
		pDC->MoveTo(m_rcBoundRect.left + m_vSegments[m_vSegments.size() - 1] + 2, m_vInput[i].yPos);
		pDC->LineTo(m_rcBoundRect.right, m_vInput[i].yPos);

		if (m_vInput[i].nID) {
			pDC->TextOut(m_rcBoundRect.left + m_vSegments[m_vSegments.size() - 1] + 6, m_vInput[i].yPos - PIN_SPACE, itoa(m_vInput[i].nID, buff, 10));
		}
	}

	for (size_t i = 0; i < m_vOutput.size(); ++i) {
		if (m_vOutput[i].bSelected)
			pDC->FillRect(CRect(m_rcBoundRect.left + m_vSegments[0], m_vOutput[i].yPos - 3, m_rcBoundRect.left + m_vSegments[0] + 6, m_vOutput[i].yPos + 4), &m_RedBrush);
	}

	size_t size = m_vSegments.size();
	for (size_t i = 0; i < m_vInput.size(); ++i) {
		if (m_vInput[i].bSelected)
			pDC->FillRect(CRect(m_rcBoundRect.left + m_vSegments[size - 1] - 6, m_vInput[i].yPos - 3, m_rcBoundRect.left + m_vSegments[size - 1] + 1, m_vInput[i].yPos + 4), &m_RedBrush);
	}

}

void CBus::Serialize(CArchive& ar) {
	
	CAbstractPart::Serialize(ar);
	
	if (ar.IsStoring())
	{
		long size = m_vSegments.size();
		ar << size;

		for (int i = 0; i < size; ++i)
			ar << m_vSegments[i];
	}
	else
	{
		long size;
		ar >> size;
		
		m_vSegments.resize(size);

		for (int i = 0; i < size; ++i)
			ar >>m_vSegments[i];

		for (size_t i = 0; i < m_vOutput.size(); ++i)
			m_vOutput[i].nID = long(i + 1);

		for (size_t j = 0; j < m_vInput.size(); ++j)
			m_vInput[j].nID = long(++i);

		long base = (m_rcBoundRect.Height() - (m_nOut * PIN_SPACE + m_nOut)) / 2;
		PlacePins(base, m_vOutput);

		base = (m_rcBoundRect.Height() - (m_nIn * PIN_SPACE + m_nIn)) / 2;
		PlacePins(base, m_vInput);

	}
}

//////////////////////////////////////////////////////////////////////////////

CMatrix::CMatrix(long nHeight, long nWidth): m_cNull(0) {

	Allocate(nHeight, nWidth);
}

CMatrix::~CMatrix() {

	Deallocate();
}
	
void CMatrix::Allocate(long nHeight, long nWidth) {

	m_nHeight = nHeight;
	m_nWidth = nWidth;

	m_cData = new short *[nHeight];
	for (long i = 0; i < nHeight; ++i) {
		m_cData[i] = new short[nWidth];
		memset(m_cData[i], 0, nWidth * sizeof(short));	
	}
}

void CMatrix::Deallocate() {
	if (m_cData) {
		for (long i = 0; i < m_nHeight; ++i)
			delete [] m_cData[i];

		delete [] m_cData;
		m_cData = NULL;
	}
}

short &CMatrix::operator()(long i, long j) {
	if (i >= 0 && j >= 0 && i < m_nHeight && j < m_nWidth)
		return m_cData[i][j];

	return m_cNull;
}