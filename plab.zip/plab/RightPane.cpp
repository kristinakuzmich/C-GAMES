// RightPane.cpp : implementation file
//

#include "stdafx.h"
#include "plab.h"
#include "RightPane.h"
#include ".\rightpane.h"


// CRightPane dialog

IMPLEMENT_DYNAMIC(CRightPane, CDialog)
CRightPane::CRightPane(CWnd* pParent /*=NULL*/)
	: CDialog(CRightPane::IDD, pParent)
{
}

CRightPane::~CRightPane()
{
}

void CRightPane::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CONNECTORS, m_grdConnectors);
	DDX_Control(pDX, IDC_CONNECTIVITY, m_grdConnectivity);
}


BEGIN_MESSAGE_MAP(CRightPane, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
END_MESSAGE_MAP()


// CRightPane message handlers

void CRightPane::OnBnClickedButton1()
{
	Beep(200, 200);
}
