
#ifndef __ALGS_H__
#define __ALGS_H__

#include "parts.h"

#include <vector>

typedef std::vector<int> intvect;
typedef std::vector<intvect> intvect2;

typedef std::vector<std::vector<CPoint> > ptvect2;

void compose(CMatrix &Q, CMatrix &R, intvect2 &groups, int n_size = 3);

void place(CMatrix &R, CPoint pos[], intvect &order);

void trace(connvect &connectors, CSize matrix_size, ptvect2 &result);

#endif // __ALGS_H__