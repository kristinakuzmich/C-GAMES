#ifndef __PARTS_H__
#define __PARTS_H__

#include "stdafx.h"

#include <vector>
#include <list>

#define DEFAULT_FONT_SIZE	9
#define LOOKUP_RADIUS		3

#define VIEWPORT_WIDTH		550
#define VIEWPORT_HEIGHT		510

#define GRID_OFFSETX		0
#define GRID_OFFSETY		7

#define N_PARTS				9

#define PLACERC(x, y) CRect(x - 5, y - 5, x + 5, y + 5)
#define FRAMERC(x, y) CRect(x - 8, y - 8, x + 8, y + 8)

#define CONNECTOR_COLOR RGB(7, 149, 7)
#define SELECTED_CONNECTOR_COLOR RGB(255, 0, 0)

extern const CRect rcBusRect;
extern CPoint ptvICPos[];
extern CRect rcvICPos[];

class PIN: public CObject {
public:
	long nID;
    long yPos;
	bool bSelected;
	bool bConnected;

	DECLARE_SERIAL(PIN);

	PIN(): nID(0), bSelected(false), bConnected(false) {}
	PIN(const PIN &src);
	PIN &operator=(const PIN &src);
	virtual void Serialize(CArchive& ar);
};

class CPartBase: public CObject {
protected:

	long m_nID;
	virtual void Render(CDC *pDC) {}

	DECLARE_SERIAL(CPartBase);
public:

	static const long PIN_SPACE = DEFAULT_FONT_SIZE + 6;
	static const long PIN_SIZE = 12;

	static long m_nNextID;
	static long m_nNextOut;

	CPartBase(bool bNeedID = true) {if (bNeedID) m_nID = m_nNextID++;}

	long ID() {return m_nID;}

	virtual void Serialize(CArchive& ar);
};

class CAbstractPart;
class CConnector;
class CBus;

typedef std::vector<CAbstractPart *> partvect;
typedef std::vector<long> longvect;
typedef std::vector<PIN> pinvect;
typedef std::list<CConnector> connvect;

class CConnector: public CPartBase {
friend class CAbstractPart;
friend class CBus;
private:
	long m_nOutPartID;
	long m_nOutPartIndex;
	long m_nOutID;
	CPoint m_ptOutPos;
	long m_nInPartID;
	long m_nInPartIndex;
	long m_nInID;
	CPoint m_ptInPos;

	bool m_bSelected;
	long m_xInSegment;
	long m_xOutSegment;

	static CPen m_ThinPen;
	static CPen m_ThicPen;

	bool CheckBranch(long xLeft, long xRight, long yCenter, CPoint pt);
public:

	static long m_NextConnector;

	DECLARE_SERIAL(CConnector);
	CConnector(const CConnector &src):CPartBase(false) {m_nID = m_NextConnector++; this->operator=(src);} 
	CConnector():CPartBase(false), m_bSelected(false) {}
	CConnector &operator=(const CConnector &src);

	void Select(bool bSelect) {m_bSelected = bSelect;}
	virtual void Render(CDC *pDC);	

	bool Validate();
	long Peekable(CPoint pt);

	void DisconnectIn(partvect &vect);
	void DisconnectOut(partvect &vect);

	void Reconnect(partvect &vect, CBus &bus);

	CPoint GetInCell(long dx, long dy, long cell_side);
	CPoint GetOutCell(long dx, long dy, long cell_side);

	long InPartID() {return m_nInPartID;}
	long OutPartID() {return m_nOutPartID;}

	virtual void Serialize(CArchive& ar);
};

class CAbstractPart: public CPartBase {
protected:
	long m_nIn, m_nOut;
	pinvect m_vInput, m_vOutput;
	CRect m_rcBoundRect;

	static CBrush m_RedBrush;

	static void PlacePins(long yBase, pinvect &vPins);

	DECLARE_SERIAL(CAbstractPart);
	virtual void Render(CDC *pDC) {}
public:
	CAbstractPart(long nIn, long nOut);
	CAbstractPart() {CAbstractPart(0, 0);}
	virtual long LookupIn(CPoint pt);
	virtual long LookupOut(CPoint pt);

	void ConnectIn(CConnector &con, long index);
	void ConnectOut(CConnector &con, long index);

	void FreeIn(long id);
	void FreeOut(long id);

	CPoint GetInPt(int id);
	CPoint GetOutPt(int id);


	void ClearSel();

	virtual void Serialize(CArchive& ar);
};

class CIC: public CAbstractPart {
private:
	static const long BODY_WIDTH = 50;
	CPoint m_ptCenter;
	CRect m_rcBodyRect;

	COLORREF m_clColor;

public:
	DECLARE_SERIAL(CIC);

	CIC(long nIn, long nOut, CPoint ptCenter);
	CIC() {CIC(0, 0, CPoint(0, 0));}

	virtual void Render(CDC *pDC);
	void SetPos(CPoint ptCenter);

	virtual void Serialize(CArchive& ar);

	void SetColor(COLORREF color) {m_clColor = color;}
};

class CBus: public CAbstractPart {
private:
	longvect m_vSegments;
	
	static CPen m_Pen;

	long GetGreaterSegment(long xPos);
	long GetLesserSegment(long xPos);
public:
	DECLARE_SERIAL(CBus);

	CBus(long nIn, long nOut, CRect rcBounds);
	CBus() {CBus(0, 0, CRect(0, 0, 0, 0));}

	void AddSegment(long xOffset);
	virtual void Render(CDC *pDC);

	virtual long LookupIn(CPoint pt);
	virtual long LookupOut(CPoint pt);

	void ConnectToBus(CConnector &con);

	virtual void Serialize(CArchive& ar);
};

class CMatrix {
private:
	short **m_cData;
	short m_cNull;

	long m_nHeight, m_nWidth;

public:

	CMatrix(): m_cData(NULL), m_cNull(0) {}
	CMatrix(long nHeight, long nWidth);
	~CMatrix();
	
	void Allocate(long nHeight, long nWidth);
	void Deallocate();
	short &operator()(long i, long j);
	long Height() {return m_nHeight;}
	long Width() {return m_nWidth;}

};

#endif // __PARTS_H__