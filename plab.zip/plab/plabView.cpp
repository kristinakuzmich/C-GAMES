// plabView.cpp : implementation of the CplabView class
//

#include "stdafx.h"
#include "plab.h"

#include "plabDoc.h"
#include "plabView.h"
#include ".\plabview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CplabView

IMPLEMENT_DYNCREATE(CplabView, CView)

BEGIN_MESSAGE_MAP(CplabView, CView)
	// Standard printing commands
	ON_WM_CREATE()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CplabView construction/destruction

CplabView::CplabView()
{
	m_MouseState = msIdle;
}

CplabView::~CplabView()
{
}

BOOL CplabView::PreCreateWindow(CREATESTRUCT& cs)
{	

	return CView::PreCreateWindow(cs);
}

// CplabView drawing

void CplabView::OnDraw(CDC* pDC)
{
	CplabDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	//pDoc->Render(&m_DC);
	pDC->BitBlt(0, 0, VIEWPORT_WIDTH, VIEWPORT_HEIGHT, &m_DC, 0, 0, SRCCOPY);

}


// CplabView diagnostics

#ifdef _DEBUG
void CplabView::AssertValid() const
{
	CView::AssertValid();
}

void CplabView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CplabDoc* CplabView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CplabDoc)));
	return (CplabDoc*)m_pDocument;
}
#endif //_DEBUG


void CplabView::ExtractPins(int &in, int &out) {

	char buff[20];
	CMainFrame *pFrame = (CMainFrame *)GetParentFrame();
	((CEdit *)pFrame->m_dlgControls.GetDlgItem(IDC_INPUT_AMOUNT))->GetWindowText(buff, sizeof(buff));
	in = atoi(buff);
	((CEdit *)pFrame->m_dlgControls.GetDlgItem(IDC_OUTPUT_AMOUNT))->GetWindowText(buff, sizeof(buff));
	out = atoi(buff);

}

void CplabView::FillConnectorMatrix(CFlexGrd *grid, CMatrix &matrix) {
	
	CplabDoc* pDoc = GetDocument();
	if (!pDoc)
		return;

	int ncols = matrix.Width() + 1;
	int nrows = matrix.Height() + 1;

	grid->put_Cols(ncols);
	grid->put_Rows(nrows);
	for (int j = 0; j < ncols; ++j)
		grid->put_ColWidth(j, 400);
	
	char buff[20];
	connvect::iterator i = pDoc->m_vConnectors.begin();
	for (int j = 1; i != pDoc->m_vConnectors.end(); ++i, ++j) {
		grid->put_TextArray(j, itoa(i->ID(), buff, 10));
	}

	buff[0]= 'E';
	for (int j = 1; j < nrows; ++j) {
		itoa(j - 1, buff + 1, 10);
		grid->put_TextArray(j * ncols, buff);
	}

	i = pDoc->m_vConnectors.begin();
	for (int j = 0; i != pDoc->m_vConnectors.end(); ++i, ++j) {
		grid->put_TextArray((i->InPartID() + 1) * ncols + j + 1, "1");
		grid->put_TextArray((i->OutPartID() + 1) * ncols + j + 1, "1");
	}
}

void CplabView::FillConnectivityMatrix(CFlexGrd *grid, CMatrix &matrix) {
	
	int ncols = matrix.Width() + 1;
	int nrows = matrix.Height() + 1;

	grid->put_Cols(ncols);
	grid->put_Rows(nrows);
	for (int j = 0; j < ncols; ++j)
		grid->put_ColWidth(j, 280);
	
	char buff[20];
	
	buff[0]= 'E';
	for (int j = 1; j < nrows; ++j) {
		itoa(j - 1, buff + 1, 10);
		grid->put_TextArray(j * ncols, buff);
		grid->put_TextArray(j, buff);
	}

	for (int i = 0; i < matrix.Height(); ++i) 
		for (int j = 0; j < matrix.Width(); ++j) {
			if (i == j)
				grid->put_TextArray((i + 1) * ncols + j + 1, "-");
			else
				grid->put_TextArray((i + 1) * ncols + j + 1, itoa(matrix(i, j), buff, 10));
			
		}
}

// CplabView message handlers

int CplabView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	CDC *dc = GetDC();
	m_Font.CreateFont(
		-MulDiv(DEFAULT_FONT_SIZE, dc->GetDeviceCaps(LOGPIXELSY), 72),
		0,
		0,
		0,
		FW_NORMAL,
		FALSE,
		FALSE,
		FALSE,
		DEFAULT_CHARSET,
		OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_SWISS,
		"Arial"
	);

	m_DC.CreateCompatibleDC(dc);
	ReleaseDC(dc);
	m_Bitmap.CreateCompatibleBitmap(CDC::FromHandle(::GetDC(0)), VIEWPORT_WIDTH, VIEWPORT_HEIGHT);
	m_DC.SelectObject(&m_Bitmap);
	m_DC.SelectObject(&m_Font);
	m_DC.SelectStockObject(WHITE_BRUSH);
	m_DC.FillRect(CRect(0, 0, VIEWPORT_WIDTH + 1, VIEWPORT_HEIGHT + 1), CBrush::FromHandle((HBRUSH)::GetStockObject(WHITE_BRUSH)));
	
	CplabDoc* pDoc = GetDocument();
	if (!pDoc)
		return 0;

	pDoc->pView = this;

	return 0;
}

void CplabView::OnMouseMove(UINT nFlags, CPoint point)
{
	CplabDoc* pDoc = GetDocument();
	if (!pDoc)
		return;

	CDC *dc = GetDC();

	switch (m_MouseState) {
		case msIdle:
			if (pDoc->m_Bus == NULL && rcBusRect.PtInRect(point)) {
				dc->FillRect(CRect(0, 0, VIEWPORT_WIDTH + 1, VIEWPORT_HEIGHT + 1), CBrush::FromHandle((HBRUSH)::GetStockObject(WHITE_BRUSH)));
				dc->Rectangle(rcBusRect);
				m_MouseState = msWantsBus;
				break;
			}	
			if (pDoc->m_nParts < 9 && (m_nPos = pDoc->HuntPlace(point)) >= 0) {
				CGdiObject *old_brush = dc->SelectStockObject(NULL_BRUSH);
				dc->Rectangle(rcvICPos[m_nPos]);
				dc->SelectObject((CBrush *)old_brush);
				m_MouseState = msWantsPart;
				break;
			}
			if ((m_nPos = pDoc->HuntOut(point)) >= 0) {
				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msOverOut;
			}
			if ((m_nPos = pDoc->HuntConnector(point)) >= 0) {
				pDoc->GetConnector(m_nPos)->Select(true);
				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msOverConnector;
			}
			break;
		case msWantsBus:
			if (!rcBusRect.PtInRect(point)) {
				dc->FillRect(CRect(0, 0, VIEWPORT_WIDTH + 1, VIEWPORT_HEIGHT + 1), CBrush::FromHandle((HBRUSH)::GetStockObject(WHITE_BRUSH)));
				m_MouseState = msIdle;
			}
			break;
		case msWantsPart:
			if (!rcvICPos[m_nPos].PtInRect(point)) {
				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msIdle;
			}
			break;
		case msOverOut:
			if ((m_nPos = pDoc->HuntOut(point)) < 0) {
				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msIdle;
			}
			break;
		case msWantsIn:
			if ((m_nPos = pDoc->HuntIn(point)) >= 0) {
				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msOverIn;
			}
			break;
		case msOverIn:
			if ((m_nPos = pDoc->HuntIn(point)) < 0) {
				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msWantsIn;
			}
			break;
		case msOverConnector:
			if (pDoc->HuntConnector(point) < 0) {
				pDoc->GetConnector(m_nPos)->Select(false);
				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msIdle;
			}
			break;
	}

	ReleaseDC(dc);
	CView::OnMouseMove(nFlags, point);
}

void CplabView::OnLButtonDown(UINT nFlags, CPoint point)
{		
	CplabDoc* pDoc = GetDocument();
	if (!pDoc)
		return;
	switch (m_MouseState) {
		case msWantsBus: {
				int in, out;
				ExtractPins(in, out);
				pDoc->m_Bus = new CBus(in, out, rcBusRect);
				pDoc->m_Bus->AddSegment(10);
				pDoc->m_Bus->AddSegment(170);
				pDoc->m_Bus->AddSegment(330);
				pDoc->m_Bus->AddSegment(500);

				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msIdle;
			}
			break;
		case msWantsPart: {
				int in, out;
				ExtractPins(in, out);
				pDoc->m_vParts[m_nPos] = new CIC(in, out, ptvICPos[m_nPos]);
				pDoc->m_nParts++;

				pDoc->Render(&m_DC);
				Invalidate(0);
				m_nPos = -1;
				m_MouseState = msIdle;
			}
			break;
		case msOverOut:
			if (m_nPos == 0) {
				pDoc->m_Bus->ConnectOut(pDoc->m_Connector, 0);
			}
			else if (m_nPos > 0)
				pDoc->m_vParts[pDoc->FindPartPos(m_nPos)]->ConnectOut(pDoc->m_Connector, m_nPos);
			else
				break;

			m_MouseState = msWantsIn;
			break;
		case msOverIn:
			if (m_nPos == 0) {
				pDoc->m_Bus->ConnectIn(pDoc->m_Connector, 0);
			}
			else  if (m_nPos > 0)
				pDoc->m_vParts[pDoc->FindPartPos(m_nPos)]->ConnectIn(pDoc->m_Connector, m_nPos);
			else
				break;		

			if (pDoc->m_Connector.Validate()) {
				pDoc->m_Bus->ConnectToBus(pDoc->m_Connector);
				pDoc->m_vConnectors.push_back(pDoc->m_Connector);
			}

			pDoc->ClearSel();
			pDoc->Render(&m_DC);
			Invalidate(0);
			m_nPos = -1;

			m_MouseState = msIdle;
			break;
		case msOverConnector:
			m_MouseState = msSelectedConnector;
			break;
		case msSelectedConnector:
			pDoc->GetConnector(m_nPos)->Select(false);
			pDoc->Render(&m_DC);
			Invalidate(0);
			m_MouseState = msIdle;
			break;
	}

	CView::OnLButtonDown(nFlags, point);
}

void CplabView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{	
	CplabDoc* pDoc = GetDocument();
	if (!pDoc)
		return;

	if (nChar == VK_ESCAPE) {
		switch (m_MouseState) {
			case msSelectedConnector: 
				pDoc->GetConnector(m_nPos)->Select(false);
				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msIdle;
			break;
		}
	}
	if (nChar == VK_DELETE) {
		switch (m_MouseState) {
			case msSelectedConnector: 
				pDoc->DeleteConnector(m_nPos);
				pDoc->Render(&m_DC);
				Invalidate(0);
				m_MouseState = msIdle;
			break;
		}
	}
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CplabView::CallBack(bool draw) {
	m_MouseState = msIdle;
	if (draw) GetDocument()->Render(&m_DC);

	Invalidate(0);
}