#pragma once
#include "flexgrd.h"


// CRightPane dialog

class CRightPane : public CDialog
{
	DECLARE_DYNAMIC(CRightPane)

public:
	CRightPane(CWnd* pParent = NULL);   // standard constructor
	virtual ~CRightPane();

// Dialog Data
	enum { IDD = IDD_MYCTRLBAR };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CFlexGrd m_grdConnectors;
	CFlexGrd m_grdConnectivity;
	afx_msg void OnBnClickedButton1();
};
