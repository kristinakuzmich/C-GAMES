// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "plab.h"

#include "MainFrm.h"
#include ".\mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_FILL_MATRIX, OnFillMatrix)
	ON_COMMAND(ID_COMPOSE_DETAILS, OnComposeDetails)
	ON_COMMAND(ID_OLACE_DETAILS, OnOlaceDetails)
	ON_COMMAND(ID_TRACE_DETAILS, OnTraceDetails)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	// TODO: Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	m_dlgControls.Create(this, IDD_MYCTRLBAR,
		CBRS_RIGHT|CBRS_TOOLTIPS|CBRS_FLYBY, IDD_MYCTRLBAR);

	//m_wndRightPane.Create(MAKEINTRESOURCE(IDD_MYCTRLBAR), this);

	((CEdit *)m_dlgControls.GetDlgItem(IDC_INPUT_AMOUNT))->SetWindowText("5");
	((CEdit *)m_dlgControls.GetDlgItem(IDC_OUTPUT_AMOUNT))->SetWindowText("5");
	((CSpinButtonCtrl *)m_dlgControls.GetDlgItem(IDC_IN_SPIN))->SetRange32(2, 10);
	((CSpinButtonCtrl *)m_dlgControls.GetDlgItem(IDC_OUT_SPIN))->SetRange32(2, 10);
	//((CFlexGrd *)m_dlgControls.GetDlgItem(IDC_CONNECTORS))->put_ColWidth(20);

	/*CListCtrl *pList = (CListCtrl *)m_dlgControls.GetDlgItem(IDC_CONNECTORS);
	pList->SetExtendedStyle(LVS_EX_FULLROWSELECT);
	pList->InsertColumn(0, "����� 1", LVCFMT_LEFT, 55);
	pList->InsertColumn(1, "�����", LVCFMT_LEFT, 45);
	pList->InsertColumn(2, "����� 2", LVCFMT_LEFT, 55);
	pList->InsertColumn(3, "����", LVCFMT_LEFT, 45);*/

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers



void CMainFrame::OnFillMatrix()
{
	
}

void CMainFrame::OnFileOpen()
{
	OnCommand(ID_FILE_OPEN, 0);
}

void CMainFrame::OnComposeDetails()
{
	ShellExecute(m_hWnd, "open", "notepad", "compose.log", NULL, SW_SHOW);
}

void CMainFrame::OnOlaceDetails()
{
	ShellExecute(m_hWnd, "open", "notepad", "place.log", NULL, SW_SHOW);
}

void CMainFrame::OnTraceDetails()
{
	ShellExecute(m_hWnd, "open", "notepad", "trace.log", NULL, SW_SHOW);
}
