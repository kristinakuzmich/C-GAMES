// plabView.h : interface of the CplabView class
//


#pragma once

#include "mainfrm.h"

enum MOUSE_STATE {
	msIdle,
	msWantsBus,
	msWantsPart,
    msOverOut,
	msWantsIn,
	msOverIn,
	msOverConnector,
	msSelectedConnector
};

class CplabView : public CView
{
protected: // create from serialization only
	CplabView();
	DECLARE_DYNCREATE(CplabView)

// Attributes
public:
	CplabDoc* GetDocument() const;

// Operations
public:

	void FillConnectorMatrix(CFlexGrd *grid, CMatrix &matrix);
	void FillConnectivityMatrix(CFlexGrd *grid, CMatrix &matrix);
// Overrides
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CplabView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CFont m_Font;
	CDC m_DC;
	CBitmap m_Bitmap;

	MOUSE_STATE m_MouseState;
	int m_nPos;
	
	void ExtractPins(int &in, int &out);

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	void CallBack(bool draw = true); 
};

#ifndef _DEBUG  // debug version in plabView.cpp
inline CplabDoc* CplabView::GetDocument() const
   { return reinterpret_cast<CplabDoc*>(m_pDocument); }
#endif

