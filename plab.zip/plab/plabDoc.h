// plabDoc.h : interface of the CplabDoc class
//


#pragma once

#include "parts.h"
#include "algs.h"

#include <vector>

class CplabView;

class CplabDoc : public CDocument
{
protected: // create from serialization only
	CplabDoc();
	DECLARE_DYNCREATE(CplabDoc)

public:

	partvect m_vParts;
	CBus *m_Bus;

	connvect m_vConnectors;
	CConnector m_Connector;
	connvect::iterator m_ConnIterator;

	CMatrix m_mxConnectivity;
	CMatrix m_mxConnectors;

// Attributes
public:

// Operations
public:
	void Render(CDC *pDC);
	int HuntIn(CPoint pt);
	int HuntOut(CPoint pt);
	int HuntPlace(CPoint pt);
	int HuntConnector(CPoint pt);
	connvect::iterator &GetConnector(int n);
	void DeleteConnector(int pos);
	int FindPartPos(int id);
	void ClearSel();


	ptvect2 m_traces;
	bool traced;
	void RenderTraces(ptvect2 &traces, CDC *pDC);

	bool FillMatrices();

	int m_nParts;

	CplabView *pView;

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);


// Implementation
public:
	virtual ~CplabDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnCompose();
	afx_msg void OnFillMatrix();
	afx_msg void OnPlace();
	afx_msg void OnTrace();
};


