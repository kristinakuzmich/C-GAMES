//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by plab.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_SIDEBAR                     101
#define IDD_MYCTRLBAR                   101
#define IDR_MAINFRAME                   128
#define IDR_plabTYPE                    129
#define IDD_DIALOG1                     130
#define IDB_BITMAP1                     132
#define IDC_EDIT1                       1001
#define IDC_INPUT_AMOUNT                1001
#define IDC_SPIN1                       1003
#define IDC_IN_SPIN                     1003
#define IDC_EDIT2                       1004
#define IDC_OUTPUT_AMOUNT               1004
#define IDC_SPIN2                       1005
#define IDC_OUT_SPIN                    1005
#define IDC_BUTTON1                     1006
#define IDC_CREATE_BUS                  1006
#define IDB_BOOK                        1006
#define IDC_MSFLEXGRID1                 1008
#define IDC_CONNECTIVITY                1008
#define IDC_CONNECTORS                  1012
#define ID_FILL_MATRIX                  32771
#define ID_COMPOSE                      32774
#define ID_PLACE                        32778
#define ID_TRACE                        32780
#define ID_COMPOSE_DETAILS              32782
#define ID_OLACE_DETAILS                32783
#define ID_TRACE_DETAILS                32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
