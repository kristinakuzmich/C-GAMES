// plabDoc.cpp : implementation of the CplabDoc class
//

#include "stdafx.h"
#include "plab.h"

#include "plabDoc.h"
#include "plabView.h"
#include ".\plabdoc.h"

#include <fstream>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CplabDoc

IMPLEMENT_DYNCREATE(CplabDoc, CDocument)

BEGIN_MESSAGE_MAP(CplabDoc, CDocument)
	ON_COMMAND(ID_COMPOSE, OnCompose)
	ON_COMMAND(ID_FILL_MATRIX, OnFillMatrix)
	ON_COMMAND(ID_PLACE, OnPlace)
	ON_COMMAND(ID_TRACE, OnTrace)
END_MESSAGE_MAP()


// CplabDoc construction/destruction

CplabDoc::CplabDoc(): m_Bus(NULL), m_nParts(0)
{

	m_vParts.resize(N_PARTS);
	for (size_t i = 0; i < m_vParts.size(); ++i)
		m_vParts[i] = NULL;

	traced = false;
}

CplabDoc::~CplabDoc()
{
	for (size_t i = 0; i < m_vParts.size(); ++i)
		delete m_vParts[i];

	delete m_Bus;
}


void CplabDoc::Render(CDC *pDC) {

	pDC->FillRect(CRect(0, 0, VIEWPORT_WIDTH + 1, VIEWPORT_HEIGHT + 1), CBrush::FromHandle((HBRUSH)::GetStockObject(WHITE_BRUSH)));
	
	if (m_Bus) {
		if (traced)
			RenderTraces(m_traces, pDC);
		else {
			m_Bus->Render(pDC);

			for (size_t i = 0; i < m_vParts.size(); ++i)
				if (m_vParts[i] != NULL)
					m_vParts[i]->Render(pDC);
				else {
					pDC->FillRect(PLACERC(ptvICPos[i].x, ptvICPos[i].y), CBrush::FromHandle((HBRUSH)::GetStockObject(BLACK_BRUSH)));
				}

			for (connvect::iterator i = m_vConnectors.begin(); i != m_vConnectors.end(); ++i)
				i->Render(pDC);
		}

	}

}

void CplabDoc::RenderTraces(ptvect2 &traces, CDC *pDC) {

	//pDC->FillRect(CRect(0, 0, VIEWPORT_WIDTH + 1, VIEWPORT_HEIGHT + 1), CBrush::FromHandle((HBRUSH)::GetStockObject(WHITE_BRUSH)));
	
	CPen pen(PS_SOLID, 1, 0xAA0000);
	CPen gpen(PS_SOLID, 1, 0x00AA00);

	/*CPen *old_pen = pDC->SelectObject(&pen);

	int grid_width = VIEWPORT_WIDTH / (CPartBase::PIN_SPACE + 1);
	int grid_height = VIEWPORT_HEIGHT / (CPartBase::PIN_SPACE + 1);

	for (int i = 1; i < grid_width; ++i) {
		pDC->MoveTo(i * (CPartBase::PIN_SPACE + 1), 0);
		pDC->LineTo(i * (CPartBase::PIN_SPACE + 1), VIEWPORT_HEIGHT);
	}

	for (int i = 1; i < grid_height; ++i) {
		pDC->MoveTo(0, i * (CPartBase::PIN_SPACE + 1) + 7);
		pDC->LineTo(VIEWPORT_WIDTH, i * (CPartBase::PIN_SPACE + 1) + 7);
	}

	pDC->SelectObject(old_pen);*/

	CBrush brush(0x0000FF);
	CBrush gbrush(0x00AA00);

	CBrush *old_brush = pDC->SelectObject(&brush);

	int cell_side = CPartBase::PIN_SPACE + 1;
	pen.DeleteObject();
	pen.CreatePen(PS_SOLID, 1, 0x0000FF);

	CPen *old_pen = pDC->SelectObject(&pen);

	connvect::iterator ii = m_vConnectors.begin();

	for (int i = 0; i < traces.size(); ++i, ++ii) {
		int x1, y1, x2, y2;
		
		if (!traces[i].size()) {
			CPoint in = ii->GetInCell(0, 7, cell_side);
			CPoint out = ii->GetOutCell(0, 7, cell_side);

			x1 = (in.x + 1) * cell_side - cell_side / 2;
			y1 = (in.y + 1) * cell_side - cell_side / 2 + 7;

			x2 = (out.x + 1) * cell_side - cell_side / 2;
			y2 = (out.y + 1) * cell_side - cell_side / 2 + 7;

			CBrush *old_brush = pDC->SelectObject(&gbrush);
			CPen *old_pen = pDC->SelectObject(&gpen);
			
			pDC->MoveTo(x1, y1);
			pDC->LineTo(x2, y2);

			pDC->Ellipse(x1 - 3, y1 - 3, x1 + 3, y1 + 3);
			pDC->Ellipse(x2 - 3, y2 - 3, x2 + 3, y2 + 3);

			pDC->SelectObject(old_brush);
			pDC->SelectObject(old_pen);

			continue;
		}

		for (int j = 0; j < traces[i].size() - 1; ++j) {
			
			x1 = (traces[i][j].x + 1) * cell_side - cell_side / 2;
			y1 = (traces[i][j].y + 1) * cell_side - cell_side / 2 + 7;
			
			x2 = (traces[i][j + 1].x + 1) * cell_side - cell_side / 2;
			y2 = (traces[i][j + 1].y + 1) * cell_side - cell_side / 2 + 7;

			pDC->MoveTo(x1, y1);
			pDC->LineTo(x2, y2);

		}

		int x = (traces[i][0].x + 1) * cell_side - cell_side / 2;
		int y = (traces[i][0].y + 1) * cell_side - cell_side / 2 + 7;

		pDC->Ellipse(x - 3, y - 3, x + 3, y + 3);

		int last = traces[i].size() - 1;
		x = (traces[i][last].x + 1) * cell_side - cell_side / 2;
		y = (traces[i][last].y + 1) * cell_side - cell_side / 2 + 7;

		pDC->Ellipse(x - 3, y - 3, x + 3, y + 3);

	}

	pDC->SelectObject(old_pen);
	pDC->SelectObject(old_brush);

}

int CplabDoc::HuntIn(CPoint pt) {
	if (m_Bus != NULL)
		if (m_Bus->LookupIn(pt) >= 0) return m_Bus->ID();

	for (size_t i = 0; i < m_vParts.size(); ++i)
		if (m_vParts[i] != NULL) {
			if (m_vParts[i]->LookupIn(pt) >= 0) return m_vParts[i]->ID();
		}

	return -1;
}

int CplabDoc::HuntOut(CPoint pt) {
	if (m_Bus != NULL)
		if (m_Bus->LookupOut(pt) >= 0) return m_Bus->ID();

	for (size_t i = 0; i < m_vParts.size(); ++i)
		if (m_vParts[i] != NULL) {
			if (m_vParts[i]->LookupOut(pt) >= 0) return m_vParts[i]->ID();
		}

	return -1;
}

int CplabDoc::HuntPlace(CPoint pt) {

	for (size_t i = 0; i < m_vParts.size(); ++i)
		if (m_vParts[i] == NULL && rcvICPos[i].PtInRect(pt)) {
			return (int)i;
		}

	return -1;
}

int CplabDoc::HuntConnector(CPoint pt) {
	int res  = -1;
	connvect::iterator i = m_vConnectors.begin();
	for (int j = 0; i != m_vConnectors.end(); ++i, ++j)
		if (i->Peekable(pt) >= 0) {
			res = j;
			break;
		}
	return res;
}

connvect::iterator &CplabDoc::GetConnector(int n) {
	m_ConnIterator = m_vConnectors.begin();
	for (int j = 0; j < n; ++m_ConnIterator, ++j);
	return m_ConnIterator;
}

void CplabDoc::DeleteConnector(int pos) {
	connvect::iterator i = GetConnector(pos);
	i->DisconnectIn(m_vParts);
	i->DisconnectOut(m_vParts);

	partvect busvect(1);
	busvect[0] = m_Bus;
	i->DisconnectIn(busvect);
	i->DisconnectOut(busvect);

	m_vConnectors.erase(i);
}

int CplabDoc::FindPartPos(int id) {

	for (size_t i = 0; i < m_vParts.size(); ++i)
		if (m_vParts[i] != NULL && m_vParts[i]->ID() == id) {
			return (int)i;
		}

	return -1;
}

void CplabDoc::ClearSel() {
	if (m_Bus) m_Bus->ClearSel();

	for (size_t i = 0; i < m_vParts.size(); ++i)
		if (m_vParts[i] != NULL)
			m_vParts[i]->ClearSel();
}

bool CplabDoc::FillMatrices() {

	if (m_nParts < 2 || !m_vConnectors.size())
		return false;

	m_mxConnectors.Deallocate();
	m_mxConnectors.Allocate(m_nParts + 1, (int)m_vConnectors.size());

	connvect::iterator i = m_vConnectors.begin();
	for (int j = 0; i != m_vConnectors.end(); ++i, ++j) {
		m_mxConnectors(i->InPartID(), j) = 1;
		m_mxConnectors(i->OutPartID(), j) = 1;	
	}

	m_mxConnectivity.Deallocate();
	m_mxConnectivity.Allocate(m_nParts + 1, m_nParts + 1);

	for (int i = 0; i < m_mxConnectivity.Height(); ++i)
		for (int j = 0; j < m_mxConnectivity.Width(); ++j)
			m_mxConnectivity(i, j) = 0;

	for (int e = 0; e < m_nParts; ++e) {
		for (int v = 0; v < m_vConnectors.size(); ++v) {
			if (m_mxConnectors(e, v)) {
				for (int e1 = e + 1; e1 < m_nParts + 1; ++e1) {
					if (m_mxConnectors(e1, v)) {
						m_mxConnectivity(e, e1)++;
						m_mxConnectivity(e1, e)++;
						break;
					}
				}
			}
		}
	}

	return true;
}

////////////////////////////////////////////////////////////////////////
BOOL CplabDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	if (m_Bus) {
		delete m_Bus;
		m_Bus = 0;
	}

	m_nParts = 0;
	for (int i = 0; i < m_vParts.size(); ++i)
		if (m_vParts[i]) {
			delete m_vParts[i];
			m_vParts[i] = NULL;
		}

	m_vConnectors.resize(0);

	CPartBase::m_nNextID = 0;
	CPartBase::m_nNextOut = 1;

	CConnector::m_NextConnector = 1;
	traced = false;

	pView->CallBack();

	return TRUE;
}


// CplabDoc serialization
void CplabDoc::Serialize(CArchive& ar)
{
	CObject::Serialize(ar);

	if (ar.IsStoring())
	{
		if (!m_Bus) return;

		m_Bus->Serialize(ar);

		size_t nparts = m_vParts.size();

		ar << nparts;
		for (int i = 0; i < nparts; ++i)
			ar << (DWORD)m_vParts[i];

		for (int i = 0; i < nparts; ++i)
			if (m_vParts[i])
				m_vParts[i]->Serialize(ar);

		ar << m_vConnectors.size();
		connvect::iterator c = m_vConnectors.begin();
		for (; c != m_vConnectors.end(); ++c)
			c->Serialize(ar);

		ar << CPartBase::m_nNextID;
		ar << CPartBase::m_nNextOut;
		ar << CConnector::m_NextConnector;
	}
	else
	{
		if (m_Bus)
			delete m_Bus;

		m_Bus = new CBus;

		m_Bus->Serialize(ar);

		size_t nparts = m_vParts.size();

		for (int i = 0; i < nparts; ++i)
			delete m_vParts[i];

		ar >> nparts;
		m_vParts.resize(nparts);

		DWORD tmp;
		for (int i = 0; i < nparts; ++i) {
			ar >> tmp;
			m_vParts[i] = (CAbstractPart* )tmp;
		}

		m_nParts = 0;
		for (int i = 0; i < nparts; ++i)
			if (m_vParts[i]) {
				m_vParts[i] = new CIC;
				m_vParts[i]->Serialize(ar);
				++m_nParts;
			}

		ar >> nparts;
		m_vConnectors.resize(0);

		for (int i = 0; i < nparts; ++i) {
			m_vConnectors.push_back(CConnector());
			(--m_vConnectors.end())->Serialize(ar);
		}

		ar >> CPartBase::m_nNextID;
		ar >> CPartBase::m_nNextOut;
		ar >> CConnector::m_NextConnector;

		traced = false;
		pView->CallBack();
	}
}


// CplabDoc diagnostics

#ifdef _DEBUG
void CplabDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CplabDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CplabDoc commands

void CplabDoc::OnFillMatrix() {
	if (FillMatrices()) {
		pView->FillConnectorMatrix((CFlexGrd *)((CMainFrame *)pView->GetParentFrame())->m_dlgControls.GetDlgItem(IDC_CONNECTORS), m_mxConnectors);
		pView->FillConnectivityMatrix((CFlexGrd *)((CMainFrame *)pView->GetParentFrame())->m_dlgControls.GetDlgItem(IDC_CONNECTIVITY), m_mxConnectivity);
	}
}

void CplabDoc::OnCompose() {
	intvect2 groups;

	COLORREF colors[] = {RGB(0xFF, 0, 0), RGB(0, 0, 0xFF), RGB(0xFF, 0, 0xFF), RGB(0xFF, 0xFF, 0), RGB(0, 0xFF, 0xFF)};

	OnFillMatrix();
	compose(m_mxConnectors, m_mxConnectivity, groups);

	for (int i = 0; i < groups.size(); ++i) {
		for (int j = 0; j < m_vParts.size(); ++j) {
			for (int l = 0; l < groups[i].size(); ++l) {
				if (m_vParts[j] && m_vParts[j]->ID() == groups[i][l])
					((CIC *)m_vParts[j])->SetColor(colors[i]);
			}
		}
	}

	pView->CallBack();

}

void CplabDoc::OnPlace() {
	intvect newpos(m_vParts.size());

	OnFillMatrix();
	place(m_mxConnectivity, ptvICPos, newpos);
	
	for (int i = 0; i < newpos.size(); ++i) {
		for (int j = i; j < m_vParts.size(); ++j) {
			if (m_vParts[j] && m_vParts[j]->ID() == newpos[i]) {
				CAbstractPart *tmp = m_vParts[j];
				m_vParts[j] = m_vParts[i];
				m_vParts[i] = tmp;
				((CIC *)m_vParts[i])->SetPos(ptvICPos[i]);
				break;
			}
		}
	}

	connvect::iterator c = m_vConnectors.begin();
	for (; c != m_vConnectors.end(); ++c)
		c->Reconnect(m_vParts, *m_Bus);

	pView->CallBack();

}

void CplabDoc::OnTrace()
{
	
	int grid_width = VIEWPORT_WIDTH / (CPartBase::PIN_SPACE + 1);
	int grid_height = VIEWPORT_HEIGHT / (CPartBase::PIN_SPACE + 1);

	trace(m_vConnectors, CSize(grid_width - 2, grid_height - 2), m_traces);

	traced = true;

	pView->CallBack();

}
