//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TForm1 *Form1;
int X0,Y0,X1,Y1;
int figure=1,rect=0;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::FormCreate(TObject *Sender)
{
 Image3->Canvas->Pixels[0][0];
 Image1->Canvas->Brush->Color = clBlack;
 Image2->Canvas->Brush->Color = clWhite;
 Image1->Canvas->FillRect(Rect(0,0,Image1->Width,Image1->Height));
 Image2->Canvas->FillRect(Rect(0,0,Image2->Width,Image2->Height));
 int HW = Image4->Width / 10;
 for (int i=1; i<=10; i++)
 {
  switch (i)
  {
   case 1: Image4->Canvas->Brush->Color = clBlack;
           break;
   case 2: Image4->Canvas->Brush->Color = clAqua;
           break;
   case 3: Image4->Canvas->Brush->Color = clBlue;
           break;
   case 4: Image4->Canvas->Brush->Color = clFuchsia;
           break;
   case 5: Image4->Canvas->Brush->Color = clGreen;
           break;
   case 6: Image4->Canvas->Brush->Color = clLime;
           break;
   case 7: Image4->Canvas->Brush->Color = clMaroon;
           break;
   case 8: Image4->Canvas->Brush->Color = clRed;
           break;
   case 9: Image4->Canvas->Brush->Color = clYellow;
           break;
   case 10: Image4->Canvas->Brush->Color = clWhite;
  }
  Image4->Canvas->Rectangle((i-1)*HW,0,i*HW,Image4->Height);
  }
  BitMap->Assign(Image3->Picture);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N2Click(TObject *Sender)
{
 if(OpenPictureDialog1->Execute())(
    Image3->Picture->LoadFromFile(OpenPictureDialog1->FileName));
    BitMap->Assign(Image3->Picture);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Image3MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
  if (Button==mbLeft)
        {
                X0=X;
                Y0=Y;
                X1=X;
                Y1=Y;
                Image3->Canvas->Pen->Mode = pmNotXor;
        }

 if((Sender==Image4) || SpeedButton2->Down)
   {
     if(Button==mbLeft)
     {
      Image1->Canvas->Brush->Color=((TImage *)Sender)->Canvas->Pixels[X][Y];
      Image1->Canvas->FillRect(Rect(0,0,Image1->Width,Image1->Height));
     }
     else
     {
      Image2->Canvas->Brush->Color=((TImage *)Sender)->Canvas->Pixels[X][Y];
      Image2->Canvas->FillRect(Rect(0,0,Image2->Width,Image2->Height));
     }
    }
    else if (SpeedButton1->Down)
    {
     if (Button==mbLeft)
     Image3->Canvas->Brush->Color=Image1->Canvas->Brush->Color;
     else Image3->Canvas->Brush->Color=Image2->Canvas->Brush->Color;
     Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
    }
    /*if ( (SB2->Down) || (SB3->Down) || (SB4->Down))
        X0=X;Y0=Y;Flag=0;

   /* X0=X;
    Y0=Y;

    R.Top = X;
    R.Bottom = X;
    R.Left = Y;
    R.Right = Y;

    Image3->Canvas->DrawFocusRect(R);
    R.Begin = true;  */


}
//---------------------------------------------------------------------------
void __fastcall TForm1::Image4MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
 if((Sender==Image4) || SpeedButton2->Down)
   {
     if(Button==mbLeft)
     {
      Image1->Canvas->Brush->Color=((TImage *)Sender)->Canvas->Pixels[X][Y];
      Image1->Canvas->FillRect(Rect(0,0,Image1->Width,Image1->Height));
     }
     else
     {
      Image2->Canvas->Brush->Color=((TImage *)Sender)->Canvas->Pixels[X][Y];
      Image2->Canvas->FillRect(Rect(0,0,Image2->Width,Image2->Height));
     }
    }
    else if (SpeedButton1->Down)
    {
     if (Button==mbLeft)
     Image3->Canvas->Brush->Color=Image1->Canvas->Brush->Color;
     else Image3->Canvas->Brush->Color=Image2->Canvas->Brush->Color;
     Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::N3Click(TObject *Sender)
{
 if(SavePictureDialog1->Execute())
 {
  Image3->Picture->SaveToFile(SavePictureDialog1->FileName);
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Image3MouseUp(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
if (Button==mbLeft)
        switch(figure)
                {
                case 1:
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X1,Y1);
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X,Y);
                        Image3->Canvas->Pen->Mode = pmCopy;

                        break;
                case 2:
                        Image3->Canvas->Rectangle(X0,Y0,X1,Y1);
                        Image3->Canvas->Rectangle(X0,Y0,X,Y);
                        Image3->Canvas->Pen->Mode = pmCopy;
                        break;
                case 3:
                        if (abs(X0-X)!=abs(Y0-Y))
                        Y=Y0-X0+X;
                        Image3->Canvas->Ellipse(X0,Y0,X1,Y1);
                        Image3->Canvas->Ellipse(X0,Y0,X,Y);
                        break;
                        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::N5Click(TObject *Sender)
{

figure=1;
N5->Checked=true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::N6Click(TObject *Sender)
{
figure=2;
N6->Checked=true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::N7Click(TObject *Sender)
{
figure=3;
N7->Checked=true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Image3MouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
if (Shift.Contains(ssLeft))
        switch(figure)
                {
                case 1:
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X1,Y1);
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X,Y);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;

                        break;
                case 2:
                        Image3->Canvas->Rectangle(X0,Y0,X1,Y1);
                        Image3->Canvas->Rectangle(X0,Y0,X,Y);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;
                        break;
                case 3:
                        if (abs(X0-X)!=abs(Y0-Y))
                        Y=Y0-X0+X;
                        Image3->Canvas->Ellipse(X0,Y0,X1,Y1);
                        Image3->Canvas->Ellipse(X0,Y0,X,Y);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;
                        break;
                        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton2Click(TObject *Sender)
{
if (((TSpeedButton *)Sender)->Down)
        BitMap->Assign(Image3->Picture);        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormDestroy(TObject *Sender)
{
BitMap->Free();
}
//---------------------------------------------------------------------------


void __fastcall TForm1::CSpinEdit1Change(TObject *Sender)
{
Image3->Canvas->Pen->Width = CSpinEdit1->Value;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N9Click(TObject *Sender)
{
Image3->Picture->Assign(BitMap);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
if (((TSpeedButton *)Sender)->Down)
        BitMap->Assign(Image3->Picture);         
}
//---------------------------------------------------------------------------

