//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <ExtDlgs.hpp>
#include <Menus.hpp>
#include <Buttons.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
Graphics::TBitmap *BitMap = new Graphics::TBitmap;
class TFigure : public TPanel
{
  private:
	TControlCanvas *FCanvas;
	Tshap Fshape;
	TColor FColor;
  protected:
	Static TFigure *Im;
	Static Tcanvas *ParentCanvas;
  public:
	
      __fastcall TFigure (TWinControl* Owner,TCanvas *Canvas);
	__fastcall ~TFigure (voib);

 };
TFigure * TFigure :: Im=NULL;
Tcanvas * TFigure :: ParentCanvas=NULL;
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
