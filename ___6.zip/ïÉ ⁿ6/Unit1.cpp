//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TForm1 *Form1;
int X0,Y0,X1,Y1,Flag=2,color;
int figure=1,rect=0,otr=1;
bool RBegin=false,
     RCut,
     RPrep=false;
TRect R; 

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
color=clBlack;;
Image3->Canvas->Brush->Color = clWhite;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
Image3->Canvas->Pixels[0][0];
Image1->Canvas->Brush->Color = clBlack;
Image2->Canvas->Brush->Color = clWhite;
Image1->Canvas->FillRect(Rect(0,0,Image1->Width,Image1->Height));
Image2->Canvas->FillRect(Rect(0,0,Image1->Width,Image1->Height));
int HW = Image4->Width / 10;
for ( int i = 1; i<=10; i++)
{
        switch(i)
        {
                case 1:Image4->Canvas->Brush->Color = clBlack;
                        break;
                case 2:Image4->Canvas->Brush->Color = clAqua;
                        break;
                case 3:Image4->Canvas->Brush->Color = clBlue;
                        break;
                case 4:Image4->Canvas->Brush->Color = clFuchsia;
                        break;
                case 5:Image4->Canvas->Brush->Color = clGreen;
                        break;
                case 6:Image4->Canvas->Brush->Color = clLime;
                        break;
                case 7:Image4->Canvas->Brush->Color = clMaroon;
                        break;
                case 8:Image4->Canvas->Brush->Color = clRed;
                        break;
                case 9:Image4->Canvas->Brush->Color = clYellow;
                        break;
                case 10:Image4->Canvas->Brush->Color = clWhite;
                        break;
        }
        Image4->Canvas->Rectangle((i-1) *HW,0,i*HW,Image4->Height);
}
 XFORM XF;
  switch (otr)
  {
  case 1:
  XF.eM11 = -1.0;
  XF.eM12 = 0;
  XF.eM21 = 0;
  XF.eM22 = 1.0;
  break;
  case 2:
  XF.eM11 = 1.0;
  XF.eM12 = 0;
  XF.eM21 = XF.eM21=0;
  XF.eM22 = -1.0;
  break;
  }
  XF.eDx = X0 - X0 * XF.eM11 - Y0 * XF.eM21;
  XF.eDy = Y0 - X0 * XF.eM12 - Y0 * XF.eM22;


}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
BitMap->Free();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::MOpenClick(TObject *Sender)
{
if (OpenPictureDialog1->Execute())
{
        Image3->Picture->LoadFromFile(OpenPictureDialog1->FileName);
        BitMap->Assign(Image3->Picture);
}
}
//---------------------------------------------------------------------------


void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
if (((TSpeedButton *)Sender)->Down)
        BitMap->Assign(Image3->Picture);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton2Click(TObject *Sender)
{
if (((TSpeedButton *)Sender)->Down)
        BitMap->Assign(Image3->Picture);        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Image3MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
 if (Button==mbLeft)
        {
                X0=X;
                Y0=Y;
                X1=X;
                Y1=Y;
                Image3->Canvas->Pen->Mode = pmNotXor;
        }
 if (Button==mbRight)
        {
                X0=X;
                Y0=Y;
                X1=X;
                Y1=Y;
                Image3->Canvas->Pen->Mode = pmNotXor;
        }

if ((Sender == Image4) || SpeedButton2->Down)
{
        if ( Button == mbLeft)
        {
                Image1->Canvas->Brush->Color =
                        ((TImage *)Sender)->Canvas->Pixels[X][Y];
                Image1->Canvas->FillRect(Rect(0,0,Image1->Width,Image1->Height));
        }
        else
        {
                Image2->Canvas->Brush->Color =
                        ((TImage *)Sender)->Canvas->Pixels[X][Y];
                Image2->Canvas->FillRect(Rect(0,0,Image2->Width,Image2->Height));
        }
}
else if (SpeedButton1->Down)
{
        if ( Button == mbLeft )
                Image3->Canvas->Brush->Color =
                                         Image1->Canvas->Brush->Color;
        else Image3->Canvas->Brush->Color =
                                         Image2->Canvas->Brush->Color;
        Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
}
else if (SpeedButton5->Down)
{
        if ( Button == mbLeft )
                Image3->Canvas->Pen->Color =
                                         Image1->Canvas->Brush->Color;
        else Image3->Canvas->Pen->Color =
                                         Image2->Canvas->Brush->Color;
        Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
}
else if (SpeedButton4->Down)
{
        if ( Button == mbLeft )
        Image3->Canvas->Pen->Color = Image1->Canvas->Brush->Color;
        else Image3->Canvas->Pen->Color = Image2->Canvas->Brush->Color;
        Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
}
else if (SpeedButton3->Down)
{
        if ( Button == mbLeft )
                Image3->Canvas->Pen->Color =
                                         Image1->Canvas->Brush->Color;
        else Image3->Canvas->Pen->Color =
                                         Image2->Canvas->Brush->Color;
        Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
}
else if (SpeedButton6->Down)
{
       if ( Button == mbRight )
                if (! RPrep) return;
    RPrep = false;
    RBegin = true;
    X0=X;
    Y0=Y;

    R.Top = X;
    R.Bottom = X;
    R.Left = Y;
    R.Right = Y;

    Image3->Canvas->DrawFocusRect(R);

}

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Image4MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
if ((Sender == Image4) || SpeedButton2->Down)
{
        if ( Button == mbLeft)
        {
                Image1->Canvas->Brush->Color =
                        ((TImage *)Sender)->Canvas->Pixels[X][Y];
                Image1->Canvas->FillRect(Rect(0,0,Image1->Width,Image1->Height));
        }
        else
        {
                Image2->Canvas->Brush->Color =
                        ((TImage *)Sender)->Canvas->Pixels[X][Y];
                Image2->Canvas->FillRect(Rect(0,0,Image2->Width,Image2->Height));
        }
}
else if (SpeedButton1->Down)
{
        if ( Button == mbLeft )
                Image3->Canvas->Brush->Color =
                                         Image1->Canvas->Brush->Color;
        else Image3->Canvas->Brush->Color =
                                         Image2->Canvas->Brush->Color;
        Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
}
else if (SpeedButton5->Down)
{
        if ( Button == mbLeft )
                Image3->Canvas->Brush->Color =
                                         Image1->Canvas->Brush->Color;
        else Image3->Canvas->Brush->Color =
                                         Image2->Canvas->Brush->Color;
        Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
}
else if (SpeedButton4->Down)
{
        if ( Button == mbLeft )
        Image3->Canvas->Pen->Color = Image1->Canvas->Brush->Color;
        else Image3->Canvas->Pen->Color = Image2->Canvas->Brush->Color;
        Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
}
else if (SpeedButton3->Down)
{
        if ( Button == mbLeft )
                Image3->Canvas->Pen->Color =
                                         Image1->Canvas->Brush->Color;
        else Image3->Canvas->Pen->Color =
                                         Image2->Canvas->Brush->Color;
        Image3->Canvas->FloodFill(X,Y,Image3->Canvas->Pixels[X][Y],fsSurface);
}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Image3MouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
 if (Shift.Contains(ssLeft))
        switch(figure)
                {
                case 1:
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X1,Y1);
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X,Y);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;

                        break;
                case 2:
                        Image3->Canvas->Rectangle(X0,Y0,X1,Y1);
                        Image3->Canvas->Rectangle(X0,Y0,X,Y);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;
                        break;
                case 3:
                        if (abs(X0-X)!=abs(Y0-Y))
                        Y=Y0-X0+X;
                        Image3->Canvas->Ellipse(X0,Y0,X1,Y1);
                        Image3->Canvas->Ellipse(X0,Y0,X,Y);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;
                        break;
                 case 4:
                        if (! RBegin) return;
                        Image3->Canvas->DrawFocusRect(R);
                        if(X0<X){R.Left=X0;R.Right=X;}
                        else {R.Left=X; R.Right=X;}
                        if(Y0<Y) {R.Top=Y0; R.Bottom=Y;}
                        else {R.Top=Y; R.Bottom=Y0;}
                        Image3->Canvas->DrawFocusRect(R);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;
                        break;
                        }
 if (Shift.Contains(ssRight))
        switch(figure)
                {
                case 1:
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X1,Y1);
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X,Y);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;

                        break;
                case 2:
                        Image3->Canvas->Rectangle(X0,Y0,X1,Y1);
                        Image3->Canvas->Rectangle(X0,Y0,X,Y);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;
                        break;
                case 3:
                        if (abs(X0-X)!=abs(Y0-Y))
                        Y=Y0-X0+X;
                        Image3->Canvas->Ellipse(X0,Y0,X1,Y1);
                        Image3->Canvas->Ellipse(X0,Y0,X,Y);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;
                        break;
                 case 4:
                        if (! RBegin) return;
                        Image3->Canvas->DrawFocusRect(R);
                        if(X0<X){R.Left=X0;R.Right=X;}
                        else {R.Left=X; R.Right=X;}
                        if(Y0<Y) {R.Top=Y0; R.Bottom=Y;}
                        else {R.Top=Y; R.Bottom=Y0;}
                        Image3->Canvas->DrawFocusRect(R);
                        Image3->Canvas->Pen->Mode = pmNotXor;
                        X1=X;
                        Y1=Y;
                        break;
                        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Image3MouseUp(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
if (Button==mbRight)
        switch(figure)
                {
                case 1:
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X1,Y1);
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X,Y);
                        Image3->Canvas->Pen->Mode = pmCopy;

                        break;
                case 2:
                        Image3->Canvas->Rectangle(X0,Y0,X1,Y1);
                        Image3->Canvas->Rectangle(X0,Y0,X,Y);
                        Image3->Canvas->Pen->Mode = pmCopy;
                        break;
                case 3:
                        if (abs(X0-X)!=abs(Y0-Y))
                        Y=Y0-X0+X;
                        Image3->Canvas->Ellipse(X0,Y0,X1,Y1);
                        Image3->Canvas->Ellipse(X0,Y0,X,Y);
                        break;
                case 4:
                        if (! RBegin) return;
                        Image3->Canvas->DrawFocusRect(R);
                        Image3->Canvas->CopyMode = cmSrcCopy;
                        RBegin = false;
                        break;
                        }

if (Button==mbLeft)
        switch(figure)
                {
                case 1:
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X1,Y1);
                        Image3->Canvas->MoveTo(X0,Y0);
                        Image3->Canvas->LineTo(X,Y);
                        Image3->Canvas->Pen->Mode = pmCopy;

                        break;
                case 2:
                        Image3->Canvas->Rectangle(X0,Y0,X1,Y1);
                        Image3->Canvas->Rectangle(X0,Y0,X,Y);
                        Image3->Canvas->Pen->Mode = pmCopy;
                        break;
                case 3:
                        if (abs(X0-X)!=abs(Y0-Y))
                        Y=Y0-X0+X;
                        Image3->Canvas->Ellipse(X0,Y0,X1,Y1);
                        Image3->Canvas->Ellipse(X0,Y0,X,Y);
                        break;
                case 4:
                        if (! RBegin) return;
                        Image3->Canvas->DrawFocusRect(R);
                        Image3->Canvas->CopyMode = cmSrcCopy;
                        RBegin = false;
                        break;
                }



}
//---------------------------------------------------------------------------

void __fastcall TForm1::N2Click(TObject *Sender)
{
if (SavePictureDialog1->Execute())
{
        Image3->Picture->SaveToFile(SavePictureDialog1->FileName);
        
      
}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N5Click(TObject *Sender)
{
figure=1;
N5->Checked=true;          
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N7Click(TObject *Sender)
{

figure=2;
N7->Checked=true;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::N6Click(TObject *Sender)
{
figure=3;
N6->Checked=true;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::CSpinEdit1Change(TObject *Sender)
{
Image3->Canvas->Pen->Width = CSpinEdit1->Value;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::N3Click(TObject *Sender)
{
Close();         
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N9Click(TObject *Sender)
{
About->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton6Click(TObject *Sender)
{
/*DestBitmap->Height = Image3->Height;
DestBitmap->Width = Image3->Width;
X0 = Image3->Height / 2.0;
Y0 = Image3->Width / 2.0;
XFORM XF;
XF.eM11 = -1;
XF.eM12 = 0;
XF.eM21 = 0;
XF.eM22 = 1;
XF.eDx = 2*X0;
XF.eDy = 0;
SetGraphicsMode(DestBitmap->Canvas->Handle,GM_ADVANCED);
SetWorldTransform(DestBitmap->Canvas->Handle,&XF);
BitBlt(DestBitmap->Canvas->Handle,0,0,Height,Width,
Image3->Canvas->Handle,0,0,SRCCOPY);
XF.eM11 = -1;
XF.eM12 = 0;
XF.eM21 = 0;
XF.eM22 = 1;
XF.eDx = 2*X0;
XF.eDy = 0;
SetWorldTransform(DestBitmap->Canvas->Handle,&XF);
Image3->Canvas->Draw(0,0,DestBitmap);  */
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N10Click(TObject *Sender)
{
 figure=4;
N10->Checked=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton7Click(TObject *Sender)
{
/*for (int X=0; X<DestBitmap->Width; X++ )
 {
  for (int Y=0; Y<DestBitmap->Height; Y++ )
  {
   switch (otr)
   {
    case 1:
           DestBitmap->Canvas->Pixels[X][Y]=
           SrcBitmap->Canvas->Pixels[DestBitmap->Width - X - 1][Y];
           break;
    case 2:
           DestBitmap->Canvas->Pixels[X][Y]=
           SrcBitmap->Canvas->Pixels[X][DestBitmap->Height-Y-1];
           break;
           }
            }
             }
  Image3->Canvas->FillRect(R);
  Image3->Canvas->Draw(R.Left,R.Top,DestBitmap);
  delete DestBitmap;
                        */
}
//---------------------------------------------------------------------------

void __fastcall TForm1::s1Click(TObject *Sender)
{
  otr=1;
s1->Checked=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::N11Click(TObject *Sender)
{
otr=2;
N11->Checked=true;
}
//---------------------------------------------------------------------------

