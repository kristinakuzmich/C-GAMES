//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
#include <Menus.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
Graphics::TBitmap *BitMap = new Graphics::TBitmap;
Graphics::TBitmap *DestBitmap = new Graphics::TBitmap;
Graphics::TBitmap *SrcBitmap;
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TImage *Image1;
        TImage *Image2;
        TImage *Image3;
        TImage *Image4;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton2;
        TOpenPictureDialog *OpenPictureDialog1;
        TMainMenu *MainMenu1;
        TMenuItem *N1;
        TMenuItem *MOpen;
        TSpeedButton *SpeedButton4;
        TSpeedButton *SpeedButton3;
        TSpeedButton *SpeedButton5;
        TSavePictureDialog *SavePictureDialog1;
        TMenuItem *N2;
        TMenuItem *N4;
        TMenuItem *N5;
        TMenuItem *N6;
        TMenuItem *N7;
        TCSpinEdit *CSpinEdit1;
        TMenuItem *N3;
        TMenuItem *N8;
        TMenuItem *N9;
        TSpeedButton *SpeedButton6;
        TMenuItem *N10;
        TSpeedButton *SpeedButton7;
        TSpeedButton *SpeedButton8;
        TListBox *ListBox1;
        TMenuItem *fdsfds1;
        TMenuItem *s1;
        TMenuItem *N11;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall MOpenClick(TObject *Sender);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall Image3MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall Image4MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall Image3MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall Image3MouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
        void __fastcall N2Click(TObject *Sender);
        void __fastcall N5Click(TObject *Sender);
        void __fastcall N7Click(TObject *Sender);
        void __fastcall N6Click(TObject *Sender);
        void __fastcall CSpinEdit1Change(TObject *Sender);
        void __fastcall N3Click(TObject *Sender);
        void __fastcall N9Click(TObject *Sender);
        void __fastcall SpeedButton6Click(TObject *Sender);
        void __fastcall N10Click(TObject *Sender);
        void __fastcall SpeedButton7Click(TObject *Sender);
        void __fastcall s1Click(TObject *Sender);
        void __fastcall N11Click(TObject *Sender);
        
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);

};

//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
